# stream-ai-example

This directory contains all the files necessary to illustrate calculating 
arithmetic intensity using Intel's SDE and VTune tools. 

For more information, see:

https://docs.nersc.gov/performance/arithmetic_intensity/
